import type { ExtensionTargets } from '../extension-targets';
  
type Target = ExtensionTargets['admin.order-fulfilled-card.action.should-render'];
export type Api = Target['api'];
export type Output = Target['output'];


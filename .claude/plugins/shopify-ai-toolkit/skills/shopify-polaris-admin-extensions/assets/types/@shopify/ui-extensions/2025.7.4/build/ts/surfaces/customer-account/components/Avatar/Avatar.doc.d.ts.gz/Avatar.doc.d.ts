import type { ReferenceEntityTemplateSchema } from '@shopify/generate-docs';
declare const data: ReferenceEntityTemplateSchema;
export default data;
//# sourceMappingURL=Avatar.doc.d.ts.map
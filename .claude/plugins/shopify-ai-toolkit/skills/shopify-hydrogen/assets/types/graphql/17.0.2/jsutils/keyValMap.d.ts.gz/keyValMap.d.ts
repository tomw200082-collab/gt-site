import type { ObjMap } from "./ObjMap.js";
/**
 * Creates a keyed JS object from an array, given a function to produce the keys
 * and a function to produce the values from each item in the array.
 * @internal
 * @example
 * ```ts
 * const phoneBook = [
 *   { name: 'Jon', num: '555-1234' },
 *   { name: 'Jenny', num: '867-5309' },
 * ];
 *
 * const phonesByName = keyValMap(
 *   phoneBook,
 *   (entry) => entry.name,
 *   (entry) => entry.num,
 * );
 *
 * phonesByName; // => { Jon: '555-1234', Jenny: '867-5309' }
 * ```
 */
export declare function keyValMap<T, V>(list: ReadonlyArray<T>, keyFn: (item: T) => string, valFn: (item: T) => V): ObjMap<V>;

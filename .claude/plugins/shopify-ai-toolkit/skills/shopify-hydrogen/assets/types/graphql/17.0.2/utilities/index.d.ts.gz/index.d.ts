/**
 * Utilities for building schemas, working with introspection, transforming ASTs,
 * and comparing GraphQL types.
 *
 * These exports are also available from the root `graphql` package.
 * @packageDocumentation
 */
export { getIntrospectionQuery } from "./getIntrospectionQuery.js";
export type { IntrospectionOptions, IntrospectionQuery, IntrospectionSchema, IntrospectionType, IntrospectionInputType, IntrospectionOutputType, IntrospectionScalarType, IntrospectionObjectType, IntrospectionInterfaceType, IntrospectionUnionType, IntrospectionEnumType, IntrospectionInputObjectType, IntrospectionTypeRef, IntrospectionInputTypeRef, IntrospectionOutputTypeRef, IntrospectionNamedTypeRef, IntrospectionListTypeRef, IntrospectionNonNullTypeRef, IntrospectionField, IntrospectionInputValue, IntrospectionEnumValue, IntrospectionDirective, } from "./getIntrospectionQuery.js";
export { getOperationAST } from "./getOperationAST.js";
export { introspectionFromSchema } from "./introspectionFromSchema.js";
export { buildClientSchema } from "./buildClientSchema.js";
export { buildASTSchema, buildSchema } from "./buildASTSchema.js";
export type { BuildSchemaOptions } from "./buildASTSchema.js";
export { extendSchema } from "./extendSchema.js";
export { lexicographicSortSchema } from "./lexicographicSortSchema.js";
export { printSchema, printType, printDirective, printIntrospectionSchema, } from "./printSchema.js";
export { typeFromAST } from "./typeFromAST.js";
export { 
/**
 * Deprecated export retained for compatibility. Use `coerceInputLiteral()`
 * instead.
 * @deprecated use `coerceInputLiteral()` instead - will be removed in v18
 */
valueFromAST, } from "./valueFromAST.js";
export { valueFromASTUntyped } from "./valueFromASTUntyped.js";
export { 
/**
 * Deprecated export retained for compatibility. Use `valueToLiteral()`
 * instead, and take care to operate on external values.
 * @deprecated use `valueToLiteral()` instead with care to operate on external values - `astFromValue()` will be removed in v18
 */
astFromValue, } from "./astFromValue.js";
export { TypeInfo, visitWithTypeInfo } from "./TypeInfo.js";
export { replaceVariables } from "./replaceVariables.js";
export { valueToLiteral } from "./valueToLiteral.js";
export { coerceInputValue, coerceInputLiteral, } from "./coerceInputValue.js";
export { validateInputValue, validateInputLiteral, } from "./validateInputValue.js";
export { concatAST } from "./concatAST.js";
export { separateOperations } from "./separateOperations.js";
export { stripIgnoredCharacters } from "./stripIgnoredCharacters.js";
export { isEqualType, isTypeSubTypeOf, doTypesOverlap, } from "./typeComparators.js";
export { BreakingChangeType, DangerousChangeType, SafeChangeType, findBreakingChanges, findDangerousChanges, findSchemaChanges, } from "./findSchemaChanges.js";
export type { BreakingChange, DangerousChange, SafeChange, SchemaChange, } from "./findSchemaChanges.js";
export type { TypedQueryDocumentNode } from "./typedQueryDocumentNode.js";
export { resolveSchemaCoordinate, resolveASTSchemaCoordinate, } from "./resolveSchemaCoordinate.js";
export type { ResolvedSchemaElement } from "./resolveSchemaCoordinate.js";

/** @category Operations */
import type { Maybe } from "../jsutils/Maybe.js";
import type { DocumentNode, OperationDefinitionNode } from "../language/ast.js";
/**
 * Returns an operation AST given a document AST and optionally an operation
 * name. If a name is not provided, an operation is only returned if only one is
 * provided in the document.
 * @param documentAST - The parsed GraphQL document AST.
 * @param operationName - The optional operation name to select.
 * @returns The resolved operation ast.
 * @example
 * ```ts
 * import { parse } from 'graphql/language';
 * import { getOperationAST } from 'graphql/utilities';
 *
 * const document = parse('query GetName { name }');
 * const operation = getOperationAST(document, 'GetName');
 *
 * operation.name.value; // => 'GetName'
 * getOperationAST(document, 'Missing'); // => undefined
 * ```
 */
export declare function getOperationAST(documentAST: DocumentNode, operationName?: Maybe<string>): Maybe<OperationDefinitionNode>;
